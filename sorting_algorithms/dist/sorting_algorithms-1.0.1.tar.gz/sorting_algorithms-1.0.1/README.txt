Program sorts randomly generated list using different sorting algorithms
more info: https://en.wikipedia.org/wiki/Sorting_algorithm

for installation use setup.py

program includes the following modules:
bubble_sort - sorting algorithm bubble sort
insertion_sort - sorting algorithm insertion sort
merge_sort - sorting algorithm merge sort
random_list - randomly generated list of a given length

author: Daniil Shynkarenko
email: dahhwe@gmail.com