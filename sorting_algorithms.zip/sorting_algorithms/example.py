from sorting_algorithms.bubble_sort import bubble_sort
from sorting_algorithms.insertion_sort import insertion_sort
from sorting_algorithms.merge_sort import merge_sort
from sorting_algorithms.random_list import get_rand_list

# print(bubble_sort(get_rand_list()))
# print(insertion_sort(get_rand_list()))
# print(merge_sort(get_rand_list()))
