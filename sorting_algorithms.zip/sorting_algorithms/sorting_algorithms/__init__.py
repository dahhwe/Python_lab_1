"""
:authors: daniildak1ng

copyright: (c) 2021 daniildak1ng
"""

from .bubble_sort import bubble_sort
from .insertion_sort import insertion_sort
from .merge_sort import merge_sort

__author__ = 'daniildak1ng'
__version__ = '1.0.1'
__email__ = 'dahhwe@gmail.com'
