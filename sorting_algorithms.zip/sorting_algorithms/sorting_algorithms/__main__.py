"""
Шинкаренко Даниил Дмитриевич, группа КИ21-16/1Б, вариант 28
"""
from .sorting_algorithms_menu import main

if __name__ == '__main__':
    main()
